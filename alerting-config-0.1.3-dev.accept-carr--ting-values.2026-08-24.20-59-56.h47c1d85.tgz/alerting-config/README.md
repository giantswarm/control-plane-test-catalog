# alerting-config

Giant Swarm Alertmanager configuration and heartbeat definition, consumed by observability-operator

**Homepage:** <https://github.com/giantswarm/alerting-config>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| team-atlas | <atlas@giantswarm.io> |  |

## Source Code

* <https://github.com/giantswarm/alerting-config>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| managementCluster.name | string | `""` | Cluster name |
| managementCluster.pipeline | string | `""` | Pipeline identifier (e.g. stable, testing) |
| alerting.grafanaAddress | string | `""` | Grafana instance address |
| alerting.slackAPIToken | string | `""` | Slack API token for the default Slack receiver |
| alerting.cronitorHeartbeatPingKey | string | `""` | Cronitor ping key for heartbeat alerts |
| alerting.slackAppID | string | `""` | Slack app ID. Unused by this chart: it is carried in every installation's alerting values, which move here as one block. |
| alerting.cronitorHeartbeatManagementKey | string | `""` | Cronitor management key. Unused by this chart until the Heartbeat CR ships from here; carried now so the per-installation secrets move in one pass. |
| alerting.teams | list | `[]` | List of team-specific configs for per-team PagerDuty routing Expected team contents:  - name: teamA    pagerdutyToken: token-for-teamA |
