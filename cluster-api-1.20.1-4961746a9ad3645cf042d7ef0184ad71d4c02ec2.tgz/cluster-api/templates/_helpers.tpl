{{- define "cluster-api.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "cluster-api.crd-install.name" -}}
{{- printf "%s-%s" (include "cluster-api.name" .) "crd-install" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "cluster-api.crd-install.labels" -}}
app.kubernetes.io/name: {{ include "cluster-api.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: crd-install
{{- end }}

{{- define "cluster-api.crd-install.annotations" -}}
helm.sh/hook: pre-install,pre-upgrade
helm.sh/hook-delete-policy: before-hook-creation,hook-succeeded
{{- end }}
