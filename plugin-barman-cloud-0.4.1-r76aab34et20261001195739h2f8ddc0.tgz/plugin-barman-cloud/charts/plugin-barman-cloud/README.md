# plugin-barman-cloud

![Version: 0.8.1](https://img.shields.io/badge/Version-0.8.1-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v0.15.1](https://img.shields.io/badge/AppVersion-v0.15.1-informational?style=flat-square)

Helm Chart for CloudNativePG's CNPG-I backup plugin using Barman Cloud

**Homepage:** <https://cloudnative-pg.io>

About this chart
----------------

Helm chart to install the [CNPG-I Barman Cloud Plugin](https://github.com/cloudnative-pg/plugin-barman-cloud),
the [CloudNativePG](https://cloudnative-pg.io) plugin that adds backup and restore capabilities to PostgreSQL
`Cluster` resources via [Barman Cloud](https://pgbarman.org/).

**NOTE**: this chart supports only the latest point release of the plugin.

**IMPORTANT**: this chart requires a working installation of [cert-manager](https://cert-manager.io/).
Please refer to the cert-manager
[installation page](https://cert-manager.io/docs/installation/helm/) for more information.

The chart deploys the plugin only. It does **not** install the CloudNativePG operator (use the companion
[`cloudnative-pg`](https://github.com/cloudnative-pg/charts/tree/main/charts/cloudnative-pg) chart for that),
and it does not create any `Cluster` resource. To provision a PostgreSQL cluster that uses this plugin, use
the [`cluster`](https://github.com/cloudnative-pg/charts/tree/main/charts/cluster) chart
(see the [Cluster chart README](https://github.com/cloudnative-pg/charts/blob/main/charts/cluster/README.md) for details)
or apply your own `Cluster` manifest.

Getting Started
---------------

### Prerequisites

This chart requires [cert-manager](https://cert-manager.io/) to issue the plugin's TLS certificates.
Install it and wait until it is ready **before** installing this chart, otherwise the install fails because
the certificates cannot be issued.

### Add the chart repository

```console
helm repo add cnpg https://cloudnative-pg.github.io/charts
helm repo update
```

### Install the plugin

```console
helm upgrade --install plugin-barman-cloud \
  --namespace cnpg-system \
  cnpg/plugin-barman-cloud
```

See the [Values](#values) section below for the full list of configurable parameters.

### Verify the installation

```console
kubectl -n cnpg-system get deploy
kubectl -n cnpg-system rollout status deploy/plugin-barman-cloud
```

Uninstalling
------------

```console
helm uninstall plugin-barman-cloud --namespace cnpg-system
```

> **Warning**
> Uninstalling the chart does not remove the plugin's CRDs (for example `ObjectStore`). Deleting them removes
> every `ObjectStore` resource and the backup configuration it holds, so only delete the CRDs if you are sure
> no resource depends on them.

## Source Code

* <https://github.com/cloudnative-pg/plugin-barman-cloud>

## Requirements

Kubernetes: `>=1.29.0-0`

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| additionalArgs | list | `[]` | Additional arguments to be added to the operator's args list. |
| additionalEnv | list | `[]` | Array containing extra environment variables which can be templated. |
| affinity | object | `{}` | Affinity for the operator to be installed. |
| certificate.createClientCertificate | bool | `true` | Specifies whether the client certificate should be created. |
| certificate.createIssuer | bool | `true` | Specifies whether the issuer should be created. |
| certificate.createServerCertificate | bool | `true` | Specifies whether the server certificate should be created. |
| certificate.duration | string | `"2160h"` | The duration of the certificates. |
| certificate.issuerName | string | `""` | The name of the issuer to use for the certificates. |
| certificate.renewBefore | string | `"360h"` | The renew before time for the certificates. |
| commonAnnotations | object | `{}` | Annotations to be added to all other resources. |
| containerSecurityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsGroup":10001,"runAsUser":10001,"seccompProfile":{"type":"RuntimeDefault"}}` | Container Security Context. |
| crds.create | bool | `true` | Specifies whether the CRDs should be created when installing the chart. |
| dnsPolicy | string | `""` |  |
| fullnameOverride | string | `""` |  |
| hostNetwork | bool | `false` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.registry | string | `"ghcr.io"` |  |
| image.repository | string | `"cloudnative-pg/plugin-barman-cloud"` |  |
| image.tag | string | `""` | Overrides the image tag whose default is the chart appVersion. |
| imagePullSecrets | list | `[]` |  |
| logLevel | string | `"info"` | Log verbosity level for the plugin barman cloud with values: [error, warning, info, debug, trace]. |
| nameOverride | string | `""` |  |
| namespaceOverride | string | `""` |  |
| nodeSelector | object | `{}` | Nodeselector for the operator to be installed. |
| podAnnotations | object | `{}` | Annotations to be added to the pod. |
| podLabels | object | `{}` | Labels to be added to the pod. |
| podSecurityContext | object | `{"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}}` | Security Context for the whole pod. |
| priorityClassName | string | `""` | Priority indicates the importance of a Pod relative to other Pods. |
| rbac.cnpgGroup | string | `"postgresql.cnpg.io"` | The API group of the Cluster CRD the plugin is granted access to (get/list/watch on backups, update on clusters/finalizers). Override this if you run a CloudNativePG-based operator whose Cluster CRD lives under a different API group. |
| rbac.create | bool | `true` | Specifies whether Role and RoleBinding should be created. |
| replicaCount | int | `1` |  |
| resources | object | `{}` |  |
| service.ipFamilies | list | `[]` | Sets the families that should be supported and the order in which they should be applied to ClusterIP as well. Can be IPv4 and/or IPv6. |
| service.ipFamilyPolicy | string | `""` | Set the ip family policy to configure dual-stack see [Configure dual-stack](https://kubernetes.io/docs/concepts/services-networking/dual-stack/#services) |
| service.name | string | `"barman-cloud"` | DO NOT CHANGE THE SERVICE NAME as it is currently used to generate the certificate and can not be configured |
| service.port | int | `9090` |  |
| serviceAccount.create | bool | `true` | Specifies whether the service account should be created. |
| serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template. |
| sidecarImage.registry | string | `"ghcr.io"` |  |
| sidecarImage.repository | string | `"cloudnative-pg/plugin-barman-cloud-sidecar"` |  |
| sidecarImage.tag | string | `""` | Overrides the image tag whose default is the chart appVersion. |
| tolerations | list | `[]` | Tolerations for the operator to be installed. |
| topologySpreadConstraints | list | `[]` | Topology Spread Constraints for the operator to be installed. |
| updateStrategy | object | `{}` | Update strategy for the operator. ref: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#strategy |

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| itay-grudev | <itay@verito.digital> |  |
| quantumenigmaa | <thibaud.vaisseau@gmail.com> |  |
| quentinbisson | <quentin.bisson@gmail.com> |  |

Contributing
------------

Please read the [code of conduct](https://github.com/cloudnative-pg/charts/blob/main/CODE-OF-CONDUCT.md) and the
[guidelines](https://github.com/cloudnative-pg/charts/blob/main/CONTRIBUTING.md) to contribute to the project.

Copyright
---------

Helm charts for CloudNativePG are distributed under [Apache License 2.0](./LICENSE).
