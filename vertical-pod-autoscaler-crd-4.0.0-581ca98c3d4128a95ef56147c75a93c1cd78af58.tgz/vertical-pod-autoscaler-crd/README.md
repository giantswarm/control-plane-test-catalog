# vertical-pod-autoscaler-crd

![Version: 4.0.0](https://img.shields.io/badge/Version-4.0.0-informational?style=flat-square) ![AppVersion: 1.4.2](https://img.shields.io/badge/AppVersion-1.4.2-informational?style=flat-square)

A Helm chart for the Vertical Pod Autoscaler CRDs.

**Homepage:** <https://github.com/giantswarm/vertical-pod-autoscaler-crd>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| commonAnnotations | object | `{}` |  |
| commonLabels | object | `{}` |  |
