{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "pagerduty-config.labels.common" -}}
app.kubernetes.io/name: {{ include "name" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "application.giantswarm.io/team" | default "atlas" | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
Convert a values key (e.g. "lukasz_j", "robin_k") to a valid Kubernetes name segment.
Dots in email-derived keys are stored as underscores by PagerDuty; we replace them with hyphens so we have valid kubernetes resource names.
*/}}
{{- define "pagerduty-config.userName" -}}
{{- . | lower | replace "_" "-" }}
{{- end }}

{{/*
Look up a team's primary scheduleId by team name and schedule name.
Context must be a dict with keys:
  - teams:    .Values.teams
  - team:     team name (e.g. "cabbage")
  - schedule: schedule name (e.g. "cabbage")
*/}}
{{- define "pagerduty-config.teamScheduleId" -}}
{{- range .teams -}}
{{- if eq .name $.team -}}
{{- range .schedules -}}
{{- if eq .name $.schedule -}}
{{- .scheduleId -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Look up an area's catchupId by area name.
Context must be a dict with keys:
  - areas: .Values.areas
  - area:  area name (e.g. "platform")
*/}}
{{- define "pagerduty-config.areaCatchupId" -}}
{{- range .areas -}}
{{- if eq .name $.area -}}
{{- .catchupId -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Render the spec block for a Schedule resource.
Context must be a dict with keys:
  - schedule:      the schedule values object
  - restrictions:  the resolved restriction list
  - name:          the display name suffix (e.g. "TeamName On-Call Schedule")
  - externalName:  the PagerDuty ID for crossplane.io/external-name
  - resourceName:  the Kubernetes metadata.name
  - root:          the root $ context (for .Values)
*/}}
{{- define "pagerduty-config.scheduleResource" -}}
{{- $schedule := .schedule }}
{{- $restrictions := .restrictions }}
{{- $root := .root }}
---
apiVersion: schedule.pagerduty.crossplane.io/v1alpha1
kind: Schedule
metadata:
  name: {{ .resourceName }}
  labels:
    {{- include "pagerduty-config.labels.common" $root | nindent 4 }}
  {{- if .externalName }}
  annotations:
    crossplane.io/external-name: {{ .externalName }}
  {{- end }}
spec:
  forProvider:
    name: {{ .displayName }}
    description: "Managed by Crossplane (pagerduty-config)"
    timeZone: {{ $root.Values.scheduleDefaults.timeZone }}
    layer:
      - name: "On-Call Rotation"
        rotationTurnLengthSeconds: {{ $root.Values.scheduleDefaults.rotationTurnLengthSeconds }}
        start: {{ $root.Values.scheduleDefaults.layerStart | quote }}
        rotationVirtualStart: {{ $root.Values.scheduleDefaults.layerStart | quote }}
        {{- /* Reference User CRs by Kubernetes name (user-<key>) */}}
        userRefs:
          {{- range $schedule.users }}
          - name: user-{{ include "pagerduty-config.userName" . }}
          {{- end }}
        restriction:
          {{- range $restrictions }}
          - type: {{ .type }}
            startTimeOfDay: {{ .startTimeOfDay | quote }}
            durationSeconds: {{ .durationSeconds }}
            startDayOfWeek: {{ .startDayOfWeek }}
          {{- end }}
  providerConfigRef:
    name: {{ $root.Values.providerConfigName }}
{{- end }}
